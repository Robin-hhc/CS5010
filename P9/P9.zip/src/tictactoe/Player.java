package tictactoe;

public enum Player {
  X, O;

  public String toString(){
    return name();
  }
}
