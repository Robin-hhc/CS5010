package movies;

public enum TimeIndicator {
  BEFORE, DURING, AFTER
}
