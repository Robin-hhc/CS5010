package solution;

public class NothingThereException extends RuntimeException {

    public NothingThereException(String message) {
        super(message);
    }

}
